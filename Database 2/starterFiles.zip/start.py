import webapp2
import logging
import re
import jinja2
import os

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'])

class MyHandler(webapp2.RequestHandler):
    def write(self, *writeArgs):    
        self.response.write(" : ".join(writeArgs))

    def render_str(self, template, **params):
        tplt = JINJA_ENVIRONMENT.get_template('templates/'+template)
        return tplt.render(params)

    def render(self, template, **kw):
        self.write(self.render_str(template, **kw))

class MainPage(MyHandler):
    def get(self):
        logging.info("********** MainPage GET **********")
        ## OPTION 1
        ## value1_in_program = "World"
        ## value2_in_program = "Let's get started."
        ## self.render("hello.html", 
        ##             placeholder1_in_template=value1_in_program,
        ##             placeholder2_in_template=value2_in_program)

        ## OPTION 2
        ## value1_in_program = "LASA"
        ## value2_in_program = "Let's go purple."
        ## python_dictionary = {'placeholder1_in_template':value1_in_program, 'placeholder2_in_template':value2_in_program}
        ## self.render("hello.html", **python_dictionary)

        ## OPTION 3
        value1_in_program = "WORLD SERIES"
        value2_in_program = "Let's go Cardinals."
        python_dictionary = {}   # creating a new dictionary
        python_dictionary['placeholder1_in_template'] = value1_in_program
        python_dictionary['placeholder2_in_template'] = value2_in_program
        self.render("hello.html", **python_dictionary)

application = webapp2.WSGIApplication([
    ('/', MainPage)
], debug=True)
